import { useState } from 'react';
import { ChantDisplay } from './components/ChantDisplay';
import { Mala } from './components/Mala';
import { TattvaDissolver } from './components/TattvaDissolver';
import { MindCloud } from './components/MindCloud';
import { SilentMode } from './components/SilentMode';
import { Journal } from './components/Journal';
import { OmWarningModal } from './components/OmWarningModal';
import { DisclaimerModal } from './components/DisclaimerModal';
import { Button } from './components/ui/button';
import { incrementChant, resetChant, getDistortionLevel } from './utils/chantTracker';

function App() {
  const [count, setCount] = useState(0);
  const [includeOm, setIncludeOm] = useState(false);
  const [isSilentMode, setIsSilentMode] = useState(false);
  const [showTattvas, setShowTattvas] = useState(false);
  const [showOmModal, setShowOmModal] = useState(false);
  const [showJournal, setShowJournal] = useState(false);
  const [disclaimerAccepted, setDisclaimerAccepted] = useState(false);

  const distortionLevel = getDistortionLevel(count);

  const handleChant = () => {
    const newCount = incrementChant(count);
    setCount(newCount);
  };

  const handleReset = () => {
    setCount(0);
  };

  const handleChantComplete = () => {
    handleChant();
  };

  const toggleSilentMode = () => {
    setIsSilentMode(!isSilentMode);
  };

  const toggleTattvas = () => {
    setShowTattvas(!showTattvas);
  };

  const handleOmToggle = () => {
    if (!includeOm) {
      setShowOmModal(true);
    } else {
      setIncludeOm(false);
    }
  };

  const confirmOm = () => {
    setIncludeOm(true);
    setShowOmModal(false);
  };

  if (!disclaimerAccepted) {
    return <DisclaimerModal onAccept={() => setDisclaimerAccepted(true)} />;
  }

  return (
    <div 
      className="min-h-screen w-full bg-indigo-950 text-slate-200 overflow-hidden"
      style={{
        filter: isSilentMode 
          ? `blur(${distortionLevel * 0.1}px) grayscale(${distortionLevel}%) contrast(${100 + distortionLevel * 0.2}%)`
          : 'none',
      }}
    >
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Merriweather:wght@300;400;700&family=Noto+Sans+Devanagari:wght@400;700&display=swap');
      `}</style>

      <TattvaDissolver chantCount={count} isVisible={showTattvas} />
      <MindCloud chantCount={count} isVisible={showTattvas} />
      <SilentMode 
        isActive={isSilentMode} 
        distortionLevel={distortionLevel}
        onExit={toggleSilentMode}
      />

      <div className="relative z-10 min-h-screen w-full max-w-7xl mx-auto flex flex-col items-center justify-center px-6 md:px-12 py-12 space-y-16">
        
        <div className="w-full flex justify-between items-center border-b border-amber-400/10 pb-6">
          <h1 className="text-amber-300/60 font-serif text-lg tracking-[0.3em]">
            ANTARMUKHA
          </h1>
          <div className="flex gap-6">
            <Button
              onClick={toggleTattvas}
              variant="ghost"
              size="lg"
              className="text-slate-400 hover:text-amber-300 text-lg tracking-wide"
            >
              {showTattvas ? 'Hide Layers' : 'Show Layers'}
            </Button>
            <Button
              onClick={() => setShowJournal(true)}
              variant="ghost"
              size="lg"
              className="text-slate-400 hover:text-amber-300 text-lg tracking-wide"
            >
              Journal
            </Button>
          </div>
        </div>

        <div className="w-full flex justify-center">
          <ChantDisplay
            includeOm={includeOm}
            isSilentMode={isSilentMode}
            onChantComplete={handleChantComplete}
          />
        </div>

        <div className="w-full py-12">
          <Mala
            count={count}
            onIncrement={handleChant}
            onReset={handleReset}
          />
        </div>

        <div className="text-center space-y-4">
          <p className="text-6xl md:text-8xl font-serif text-amber-300 tracking-wider">
            {count}
          </p>
          <p className="text-2xl text-slate-500 font-light tracking-widest">
            OF 108 BEADS
          </p>
          <p className="text-slate-400 text-lg">
            {count === 0 ? 'Begin your practice' : 
             count === 108 ? 'Cycle complete' : 
             `${108 - count} beads remaining`}
          </p>
        </div>

        <div className="w-full max-w-4xl flex flex-col md:flex-row gap-6 items-center justify-center pt-8 border-t border-amber-400/10">
          <Button
            onClick={handleOmToggle}
            variant="outline"
            size="lg"
            className={`w-full md:w-auto px-12 py-6 text-lg border-amber-400/30 ${
              includeOm ? 'bg-amber-500/20 text-amber-300' : 'text-slate-400'
            }`}
          >
            {includeOm ? '✓ Om Namah Shivaya' : '+ Add Om?'}
          </Button>

          <Button
            onClick={toggleSilentMode}
            size="lg"
            className={`w-full md:w-auto px-12 py-6 text-lg tracking-wide ${
              isSilentMode 
                ? 'bg-indigo-800 text-amber-300' 
                : 'bg-amber-500 hover:bg-amber-400 text-indigo-950'
            }`}
          >
            {isSilentMode ? 'Exit Silent Mode' : 'Enter Silent Mode'}
          </Button>
        </div>

        {showTattvas && (
          <div className="fixed bottom-0 left-0 right-0 bg-indigo-900/95 backdrop-blur-md border-t border-amber-400/20 p-8 md:p-12">
            <div className="max-w-6xl mx-auto grid grid-cols-5 gap-8 text-center">
              {[
                { s: 'Na', m: 'Negation of ego' },
                { s: 'mah', m: 'Dissolution of magnitude' },
                { s: 'Shi', m: 'Pure awareness' },
                { s: 'va', m: 'Permeation of all' },
                { s: 'Ya', m: 'Self as illusion' }
              ].map((item) => (
                <div key={item.s} className="space-y-3">
                  <span className="block text-4xl md:text-5xl text-amber-300 font-serif">{item.s}</span>
                  <p className="text-slate-400 text-lg font-light tracking-wide">{item.m}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <OmWarningModal
        isOpen={showOmModal}
        onClose={() => setShowOmModal(false)}
        onConfirm={confirmOm}
      />

      <Journal isOpen={showJournal} onClose={() => setShowJournal(false)} />
    </div>
  );
}

export default App;