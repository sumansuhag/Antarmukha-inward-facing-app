export const BREATH_INHALE = 4000;
export const BREATH_EXHALE = 6000;
export const BREATH_CYCLE = BREATH_INHALE + BREATH_EXHALE;

export function getBreathPhase(timestamp: number): 'inhale' | 'exhale' {
  const cyclePosition = timestamp % BREATH_CYCLE;
  return cyclePosition < BREATH_INHALE ? 'inhale' : 'exhale';
}

export function getBreathProgress(timestamp: number): number {
  const cyclePosition = timestamp % BREATH_CYCLE;
  const phase = getBreathPhase(timestamp);
  
  if (phase === 'inhale') {
    return cyclePosition / BREATH_INHALE;
  } else {
    return 1 - ((cyclePosition - BREATH_INHALE) / BREATH_EXHALE);
  }
}