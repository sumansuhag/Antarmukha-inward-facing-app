export const TOTAL_BEADS = 108;
export const SYLLABLES = ['Na', 'mah', 'Shi', 'va', 'ya'];

export function incrementChant(currentCount: number): number {
  return (currentCount % TOTAL_BEADS) + 1;
}

export function resetChant(): number {
  return 0;
}

export function getDistortionLevel(count: number): number {
  if (count === 0) return 0;
  const percentage = count / TOTAL_BEADS;
  if (percentage < 0.2) return 10;
  if (percentage < 0.4) return 20;
  if (percentage < 0.6) return 30;
  if (percentage < 0.8) return 50;
  return 80;
}

export function triggerHaptic() {
  if (typeof navigator !== 'undefined' && navigator.vibrate) {
    navigator.vibrate([50]);
  }
}