export interface SyllableMeaning {
  syllable: string;
  meaning: string;
}

export interface JournalEntry {
  before: string;
  after: string;
  timestamp: number;
}

export interface ChantState {
  count: number;
  includeOm: boolean;
  isSilentMode: boolean;
  showTattvas: boolean;
  distortionLevel: number;
}