import { useState, useEffect } from 'react';

interface MindCloudProps {
  chantCount: number;
  isVisible: boolean;
}

interface Particle {
  id: number;
  x: number;
  y: number;
  dissolved: boolean;
}

export function MindCloud({ chantCount, isVisible }: MindCloudProps) {
  const [particles, setParticles] = useState<Particle[]>([]);

  useEffect(() => {
    if (!isVisible) {
      setParticles([]);
      return;
    }

    const newParticles: Particle[] = Array.from({ length: 15 }, (_, i) => ({
      id: i,
      x: 20 + Math.random() * 60,
      y: 10 + Math.random() * 30,
      dissolved: i < Math.floor(chantCount / 8),
    }));

    setParticles(newParticles);
  }, [isVisible, chantCount]);

  if (!isVisible) return null;

  return (
    <div className="fixed top-20 left-0 right-0 h-40 pointer-events-none">
      {particles.map((particle) => (
        <div
          key={particle.id}
          className={`
            absolute w-2 h-2 rounded-full transition-all duration-1000
            ${particle.dissolved 
              ? 'bg-amber-300/80 scale-0 opacity-0' 
              : 'bg-slate-500/40 scale-100 opacity-100'
            }
          `}
          style={{
            left: `${particle.x}%`,
            top: `${particle.y}%`,
            transform: particle.dissolved ? 'scale(0)' : 'scale(1)',
          }}
        />
      ))}
    </div>
  );
}