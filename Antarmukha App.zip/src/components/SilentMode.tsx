import { useEffect, useState } from 'react';
import { getBreathProgress, getBreathPhase } from '../utils/breathSync';
import { triggerHaptic } from '../utils/chantTracker';

interface SilentModeProps {
  isActive: boolean;
  distortionLevel: number;
  onExit: () => void;
}

export function SilentMode({ isActive, distortionLevel, onExit }: SilentModeProps) {
  const [breathProgress, setBreathProgress] = useState(0);
  const [phase, setPhase] = useState<'inhale' | 'exhale'>('inhale');

  useEffect(() => {
    if (!isActive) return;

    let animationFrame: number;
    let lastHaptic = 0;

    const animate = () => {
      const now = Date.now();
      setBreathProgress(getBreathProgress(now));
      setPhase(getBreathPhase(now));

      if (now - lastHaptic > 10000) {
        triggerHaptic();
        lastHaptic = now;
      }

      animationFrame = requestAnimationFrame(animate);
    };

    animationFrame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrame);
  }, [isActive]);

  if (!isActive) return null;

  const haloScale = 1 + breathProgress * 0.3;
  const haloOpacity = 0.1 + breathProgress * 0.2;

  return (
    <div className="fixed inset-0 pointer-events-none flex items-center justify-center">
      <div
        className="absolute rounded-full bg-amber-300/10 blur-3xl transition-all duration-100"
        style={{
          width: `${300 * haloScale}px`,
          height: `${300 * haloScale}px`,
          opacity: haloOpacity,
        }}
      />

      <button
        onClick={onExit}
        className="absolute bottom-8 right-8 pointer-events-auto bg-indigo-900/80 border border-amber-400/30 text-amber-300 px-4 py-2 rounded-lg hover:bg-indigo-800 transition-colors"
      >
        Return to Breath
      </button>

      <div className="absolute bottom-8 left-8 text-slate-400 text-sm">
        {phase === 'inhale' ? 'Inhale...' : 'Exhale...'}
      </div>
    </div>
  );
}