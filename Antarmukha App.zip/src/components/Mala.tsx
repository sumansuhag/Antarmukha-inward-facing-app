import { TOTAL_BEADS, triggerHaptic } from '../utils/chantTracker';

interface MalaProps {
  count: number;
  onIncrement: () => void;
  onReset: () => void;
}

export function Mala({ count, onIncrement, onReset }: MalaProps) {
  const beads = Array.from({ length: TOTAL_BEADS }, (_, i) => i);

  const handleBeadClick = (index: number) => {
    if (index === count) {
      triggerHaptic();
      onIncrement();
    }
  };

  const isComplete = count === TOTAL_BEADS;

  return (
    <div className="relative w-full max-w-5xl mx-auto">
      <div 
        className={`grid gap-2 transition-all duration-700 ${
          isComplete ? 'scale-105 opacity-50' : 'scale-100 opacity-100'
        }`}
        style={{
          gridTemplateColumns: 'repeat(18, 1fr)',
          gridTemplateRows: 'repeat(6, 1fr)',
        }}
      >
        {beads.map((index) => {
          const isActive = index < count;
          const isCurrent = index === count;
          
          return (
            <button
              key={index}
              onClick={() => handleBeadClick(index)}
              disabled={!isCurrent}
              className={`
                w-4 h-4 md:w-6 md:h-6 rounded-full transition-all duration-500
                ${isActive 
                  ? 'bg-amber-400 shadow-lg shadow-amber-400/50' 
                  : 'bg-indigo-800 border border-amber-400/30'
                }
                ${isCurrent 
                  ? 'cursor-pointer hover:scale-125 hover:bg-amber-300' 
                  : 'cursor-default'
                }
                ${isComplete && index === 0 ? 'animate-pulse' : ''}
              `}
              aria-label={`Bead ${index + 1}`}
            />
          );
        })}
      </div>

      {isComplete && (
        <button
          onClick={onReset}
          className="absolute inset-0 flex items-center justify-center pointer-events-none"
        >
          <div className="w-64 h-64 rounded-full bg-amber-400/10 animate-ping" />
        </button>
      )}
    </div>
  );
}