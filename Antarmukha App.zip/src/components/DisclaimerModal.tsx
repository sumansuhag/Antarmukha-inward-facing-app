import { useState } from 'react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';

export function DisclaimerModal({ onAccept }: { onAccept: () => void }) {
  const [isVisible, setIsVisible] = useState(true);

  const handleAccept = () => {
    localStorage.setItem('antarmukha-disclaimer', 'true');
    setIsVisible(false);
    onAccept();
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-indigo-950 flex items-center justify-center z-50 p-6">
      <Card className="max-w-md w-full bg-indigo-900 border-amber-400/30">
        <CardContent className="p-8 text-center space-y-6">
          <div className="text-amber-300 text-4xl mb-4">🙏</div>
          <h2 className="text-2xl font-serif text-amber-300">Sacred Space</h2>
          <p className="text-slate-300 leading-relaxed">
            This is not a replacement for guidance from a qualified teacher.
            Deep meditation may bring up suppressed emotions.
          </p>
          <p className="text-slate-400 text-sm italic">
            Return to breath if overwhelmed.
          </p>
          <Button 
            onClick={handleAccept}
            className="w-full bg-amber-500 hover:bg-amber-400 text-indigo-950 font-serif"
          >
            I understand
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}