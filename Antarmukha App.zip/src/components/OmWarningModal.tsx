import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Shield } from 'lucide-react';

interface OmWarningModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
}

export function OmWarningModal({ isOpen, onClose, onConfirm }: OmWarningModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-indigo-950/90 flex items-center justify-center z-50 p-6">
      <Card className="max-w-md w-full bg-indigo-900 border-amber-400/30">
        <CardContent className="p-8 text-center space-y-6">
          <div className="flex justify-center">
            <Shield className="w-12 h-12 text-amber-300" />
          </div>
          <h2 className="text-xl font-serif text-amber-300">Sacred Tradition</h2>
          <p className="text-slate-300 leading-relaxed">
            Traditionally, Pranava (Om) is received through initiation.
            Proceed only if aligned with your lineage.
          </p>
          <div className="flex items-center justify-center gap-3">
            <input 
              type="checkbox" 
              id="initiated"
              className="w-4 h-4 accent-amber-500"
              onChange={(e) => {
                const btn = document.getElementById('confirm-om') as HTMLButtonElement;
                if (btn) btn.disabled = !e.target.checked;
              }}
            />
            <label htmlFor="initiated" className="text-slate-300 text-sm">
              I am initiated
            </label>
          </div>
          <div className="flex gap-3">
            <Button 
              onClick={onClose}
              variant="outline"
              className="flex-1 border-slate-600 text-slate-300 hover:bg-slate-800"
            >
              Cancel
            </Button>
            <Button 
              id="confirm-om"
              onClick={onConfirm}
              disabled
              className="flex-1 bg-amber-500 hover:bg-amber-400 text-indigo-950"
            >
              Add Om
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}