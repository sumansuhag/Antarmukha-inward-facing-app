import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Textarea } from './ui/textarea';
import { Button } from './ui/button';
import { useLocalStorage } from '../utils/useLocalStorage';
import { JournalEntry } from '../types';

interface JournalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function Journal({ isOpen, onClose }: JournalProps) {
  const [entries, setEntries] = useLocalStorage<JournalEntry[]>('antarmukha-journal', []);
  const [before, setBefore] = useState('');
  const [after, setAfter] = useState('');

  const handleSave = () => {
    if (!before.trim() && !after.trim()) return;
    
    const entry: JournalEntry = {
      before,
      after,
      timestamp: Date.now(),
    };
    
    setEntries([entry, ...entries]);
    setBefore('');
    setAfter('');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-indigo-950 flex items-center justify-center z-40 p-6">
      <Card className="max-w-2xl w-full max-h-[90vh] overflow-y-auto bg-indigo-900 border-amber-400/30">
        <CardHeader>
          <CardTitle className="text-amber-300 font-serif text-2xl">
            Reflection
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <label className="text-slate-300 text-sm">What was present before chanting?</label>
            <Textarea
              value={before}
              onChange={(e) => setBefore(e.target.value)}
              placeholder="Thoughts, feelings, sensations..."
              className="bg-indigo-950 border-slate-700 text-slate-200 min-h-24"
            />
          </div>

          <div className="space-y-2">
            <label className="text-slate-300 text-sm">What remains now?</label>
            <Textarea
              value={after}
              onChange={(e) => setAfter(e.target.value)}
              placeholder="In the silence..."
              className="bg-indigo-950 border-slate-700 text-slate-200 min-h-24"
            />
          </div>

          <div className="flex gap-3">
            <Button
              onClick={handleSave}
              className="flex-1 bg-amber-500 hover:bg-amber-400 text-indigo-950"
            >
              Save Entry
            </Button>
            <Button
              onClick={onClose}
              variant="outline"
              className="border-slate-600 text-slate-300 hover:bg-slate-800"
            >
              Close
            </Button>
          </div>

          {entries.length > 0 && (
            <div className="pt-6 border-t border-slate-700">
              <h3 className="text-amber-300 font-serif mb-4">Previous Reflections</h3>
              <div className="space-y-4">
                {entries.slice(0, 3).map((entry, index) => (
                  <div key={index} className="bg-indigo-950 p-4 rounded-lg space-y-2">
                    {entry.before && (
                      <p className="text-slate-400 text-sm">
                        <span className="text-amber-300/60">Before:</span> {entry.before}
                      </p>
                    )}
                    {entry.after && (
                      <p className="text-slate-400 text-sm">
                        <span className="text-amber-300/60">After:</span> {entry.after}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}