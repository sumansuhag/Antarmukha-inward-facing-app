import { useEffect, useState } from 'react';
import { SYLLABLES } from '../utils/chantTracker';

interface ChantDisplayProps {
  includeOm: boolean;
  isSilentMode: boolean;
  onChantComplete: () => void;
}

export function ChantDisplay({ includeOm, isSilentMode, onChantComplete }: ChantDisplayProps) {
  const [currentSyllable, setCurrentSyllable] = useState(0);
  const [isPulsing, setIsPulsing] = useState(false);

  const allSyllables = includeOm ? ['Om', ...SYLLABLES] : SYLLABLES;

  useEffect(() => {
    if (isSilentMode) return;

    const interval = setInterval(() => {
      setIsPulsing(true);
      setTimeout(() => setIsPulsing(false), 500);
      
      setCurrentSyllable((prev) => {
        const next = (prev + 1) % allSyllables.length;
        if (next === 0) {
          onChantComplete();
        }
        return next;
      });
    }, 3000);

    return () => clearInterval(interval);
  }, [isSilentMode, allSyllables.length, onChantComplete]);

  if (isSilentMode) {
    return (
      <div className="text-center space-y-4 py-12">
        <p className="text-4xl md:text-6xl font-serif text-amber-300/80 animate-pulse tracking-widest">
          Breathe. Be. No sound.
        </p>
      </div>
    );
  }

  return (
    <div className="text-center space-y-8 py-12 w-full">
      <div className="space-y-4">
        <h1 
          className={`text-7xl md:text-9xl font-serif text-amber-300 transition-all duration-700 tracking-wide ${
            isPulsing ? 'opacity-100 scale-105' : 'opacity-80'
          }`}
          style={{ fontFamily: "'Noto Sans Devanagari', serif" }}
        >
          नमः शिवाय
        </h1>
        <p className="text-3xl md:text-5xl text-slate-300 font-serif tracking-wider">
          Namah Shivaya
        </p>
      </div>
      
      <div className="flex justify-center gap-6 md:gap-10">
        {allSyllables.map((syllable, index) => (
          <span
            key={syllable}
            className={`text-2xl md:text-4xl transition-all duration-500 font-serif tracking-widest ${
              index === currentSyllable 
                ? 'text-amber-300 opacity-100 scale-110' 
                : 'text-slate-500 opacity-30'
            }`}
          >
            {syllable}
          </span>
        ))}
      </div>
    </div>
  );
}