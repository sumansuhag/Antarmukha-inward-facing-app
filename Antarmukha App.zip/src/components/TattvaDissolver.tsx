import { Landmark, Droplet, Flame, Wind, Star } from 'lucide-react';

interface TattvaDissolverProps {
  chantCount: number;
  isVisible: boolean;
}

const TATTVAS = [
  { name: 'Earth', icon: Landmark },
  { name: 'Water', icon: Droplet },
  { name: 'Fire', icon: Flame },
  { name: 'Air', icon: Wind },
  { name: 'Space', icon: Star },
];

export function TattvaDissolver({ chantCount, isVisible }: TattvaDissolverProps) {
  if (!isVisible) return null;

  const cycle = Math.floor(chantCount / 5);
  const getOpacity = (index: number) => {
    const baseOpacity = 0.8 - (cycle * 0.12);
    return Math.max(0, baseOpacity - (index * 0.05));
  };

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {TATTVAS.map((tattva, index) => {
        const Icon = tattva.icon;
        const opacity = getOpacity(index);
        
        if (opacity <= 0) return null;

        return (
          <div
            key={tattva.name}
            className="absolute transition-opacity duration-1000"
            style={{
              opacity,
              top: `${20 + index * 15}%`,
              left: `${10 + index * 20}%`,
            }}
          >
            <Icon className="w-8 h-8 text-amber-300/30" />
          </div>
        );
      })}
    </div>
  );
}